import setuptools

setuptools.setup(
    name="test_package",
    version="0.0.1",
    author="Gus",
    description="First Test",
    packages=["test_package"]
)
